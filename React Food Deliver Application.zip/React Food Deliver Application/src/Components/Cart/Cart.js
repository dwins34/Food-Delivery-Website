import classes from "./Cart.module.css";
import Modal from "../UI/Modal";
import CartContext from "../../Store/cart-context";
import { useContext } from "react";
import CartItem from "./CartItem";
import Checkout from "./checkout";
import { useState } from "react";
const Cart = (props) => {
  const [isCheckOut, setIsCheckOut] = useState(false);
  const cartCtx = useContext(CartContext);
  const totalAmount = `$${cartCtx.totalAmount.toFixed(2)}`;

  const hasItem = cartCtx.items.length > 0;
  const cartItemRemoveHandler = (id) => {
    cartCtx.removeItem(id);
  };
  const cartItemAddhandler = (item) => {
    //Inside addItem we give the whole item and change the amount by 1 so that when we click on + button then only one time it will add
    cartCtx.addItem({ ...item, amount: 1 });
  };
  const cartItem = (
    <ul className={classes["cart-items"]}>
      {cartCtx.items.map((item) => (
        <CartItem
          key={item.id}
          name={item.name}
          price={item.price}
          amount={item.amount}
          //bind both the below function .bind(null,id) .bind(null,item)
          //to get only that single item that has to be either removed or added we are using binding below
          /*we are passing null in the bind coz no object or value is present that needs to be replaced with 
          the this keyword present inside the function cartItemRemoveHandler ie we are simply adding the item.*/
          onRemove={cartItemRemoveHandler.bind(null, item.id)}
          onAdd={cartItemAddhandler.bind(null, item)}
        />
      ))}
    </ul>
  );
  const orderHandler = () => {
    setIsCheckOut(true);
  };
  const submitOrderHandler = (userData) => {
    fetch(
      "https://react-food-delivery-e2968-default-rtdb.firebaseio.com/orders.json",

      {
        method: "POST",
        body: JSON.stringify({
          user: userData,
          orderedItem: cartCtx.items,
        }),
      }
    );
  };
  const modalAction = (
    <div className={classes.actions}>
      <button className={classes["button--alt"]} onClick={props.onClose}>
        Close
      </button>
      {hasItem && (
        <button className={classes.button} onClick={orderHandler}>
          Order
        </button>
      )}
    </div>
  );

  return (
    <Modal onClose={props.onClose}>
      {cartItem}
      <div className={classes.total}>
        <span>Total Amount</span>
        <span>{totalAmount}</span>
      </div>
      {isCheckOut && (
        <Checkout onConfirm={submitOrderHandler} onCancel={props.onClose} />
      )}
      {!isCheckOut && modalAction}
    </Modal>
  );
};

export default Cart;
