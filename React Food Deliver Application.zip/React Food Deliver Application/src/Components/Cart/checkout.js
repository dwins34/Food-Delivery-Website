import { useState } from "react";
import { useRef } from "react";
import classes from "./checkout.module.css";

const isEmpty = (value) => value.trim() === "";
const isFiveChar = (value) => value.trim().length === 5;

const Checkout = (props) => {
  const nameInputRef = useRef();
  const streetInputRef = useRef();
  const postalCodeInputRef = useRef();
  const cityInputRef = useRef();
  const [formInputIsValid, setFormInputIsValid] = useState({
    name: true,
    street: true,
    postalCode: true,
    city: true,
  });

  const confirmHandler = (event) => {
    event.preventDefault();
    const enteredName = nameInputRef.current.value;
    const enteredStreet = streetInputRef.current.value;
    const enteredPostalCode = postalCodeInputRef.current.value;
    const enteredCity = cityInputRef.current.value;

    const enteredNameIsvalid = !isEmpty(enteredName);
    const enteredStreetIsvalid = !isEmpty(enteredStreet);
    const enteredPostalCodeIsvalid = isFiveChar(enteredPostalCode);
    const enteredCityIsvalid = !isEmpty(enteredCity);

    setFormInputIsValid({
      name: enteredNameIsvalid,
      street: enteredStreetIsvalid,
      postalCode: enteredPostalCodeIsvalid,
      city: enteredCityIsvalid,
    });
    if (formInputIsValid) {
      props.onConfirm({
        name: enteredName,
        street: enteredStreet,
        city: enteredCity,
        postalCode: enteredPostalCode,
      });
    } else {
      return;
    }
  };

  const nameInputClasses = `${classes.control} ${
    formInputIsValid.name ? "" : classes.invalid
  }`;
  const streetInputClasses = `${classes.control} ${
    formInputIsValid.name ? "" : classes.invalid
  }`;
  const postalCodeInputClasses = `${classes.control} ${
    formInputIsValid.name ? "" : classes.invalid
  }`;
  const cityInputClasses = `${classes.control} ${
    formInputIsValid.name ? "" : classes.invalid
  }`;

  return (
    <form className={nameInputClasses} onSubmit={confirmHandler}>
      <div className={classes.control}>
        <label htmlFor="name">Your Name</label>
        <input type="text" id="name" ref={nameInputRef} />
        {!formInputIsValid.name && <p>Please enter a valid name!</p>}
      </div>
      <div className={streetInputClasses}>
        <label htmlFor="street">Street</label>
        <input type="text" id="street" ref={streetInputRef} />
        {!formInputIsValid.street && <p>Please enter a valid street!</p>}
      </div>
      <div className={postalCodeInputClasses}>
        <label htmlFor="postal">Postal Code</label>
        <input type="text" id="postal" ref={postalCodeInputRef} />
        {!formInputIsValid.postalCode && (
          <p>Please enter a valid postal code!</p>
        )}
      </div>
      <div className={cityInputClasses}>
        <label htmlFor="city">City</label>
        <input type="text" id="city" ref={cityInputRef} />
        {!formInputIsValid.city && <p>Please enter a valid city!</p>}
      </div>
      <div className={classes.actions}>
        <button type="button" onClick={props.onCancel}>
          Cancel
        </button>
        <button className={classes.submit}>Confirm</button>
      </div>
    </form>
  );
};

export default Checkout;
